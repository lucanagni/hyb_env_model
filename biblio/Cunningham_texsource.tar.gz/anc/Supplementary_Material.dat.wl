(* ::Package:: *)

(* ::Chapter:: *)
(*Ancillary file to "Gravitational memory: new results from post-Newtonian and self-force theory" (Kevin Cunningham, Chris Kavanagh, Adam Pound, David Trestini, Niels Warburton, Jakob Neef ), arXiv:2410.23950v2*)


(* ::Section:: *)
(*Notations*)


(* ::Text:: *)
(*Standard Wolfram Mathematica syntax and functions are used (e.g. I, Pi, EulerGamma, Sqrt[...], Log[...], Zeta[...], .) We denote the digamma function "\[Psi]0(...)" by PolyGamma[...].*)
(**)
(*We denote by "c" the speed of light, "G" the gravitational constant, "M" the total mass, "\[Nu]" the symmetric mass ratio, "\[Delta]" the relative mass difference, "\[Tau]" the dimensionless time variables, "x" the dimensionless frequency variable. We denote the spin-variables "s" and "\[Sigma]", and only present results in the spinning case. The non-spinning case is trivially obtained by setting s = \[Sigma] = 0.*)


(* ::Section:: *)
(*Energy, fluxes and phasing*)


(* ::Text:: *)
(*The following expression corresponds to Eq. (40) of the paper*)


E$3p5PN = -1/2*(c^2*M*x*\[Nu]*(1 + x*(-3/4 - \[Nu]/12) + x^(3/2)*((14*s)/3 + 2*\[Delta]*\[Sigma]) + x^(5/2)*(11*s + 3*\[Delta]*\[Sigma] + \[Nu]*((-61*s)/9 - (10*\[Delta]*\[Sigma])/3)) + 
   x^3*(-675/64 - (25*s^2)/9 - (35*\[Nu]^3)/5184 + (10*s*\[Delta]*\[Sigma])/3 + (5*\[Sigma]^2)/2 + \[Nu]*(34445/576 - (205*Pi^2)/96 + (10*s^2)/3 + (10*s*\[Delta]*\[Sigma])/3 - (15*\[Sigma]^2)/2) + 
     \[Nu]^2*(-155/96 - (10*\[Sigma]^2)/3)) + x^2*(-27/8 - 4*s^2 - \[Nu]^2/24 - 4*s*\[Delta]*\[Sigma] - \[Sigma]^2 + \[Nu]*(19/8 + 4*\[Sigma]^2)) + 
   x^(7/2)*((135*s)/4 - 8*s^3 + (27*\[Delta]*\[Sigma])/4 - 16*s^2*\[Delta]*\[Sigma] - 10*s*\[Sigma]^2 - 2*\[Delta]*\[Sigma]^3 + \[Nu]^2*((29*s)/12 + (5*\[Delta]*\[Sigma])/4) + 
     \[Nu]*((-367*s)/4 - 39*\[Delta]*\[Sigma] + 40*s*\[Sigma]^2 + 8*\[Delta]*\[Sigma]^3))));


(* ::Text:: *)
(*The following expression corresponds to Eq. (41) of the paper*)


F$infinity$3p5PN = (32*c^5*x^5*\[Nu]^2*(1 + x*(-1247/336 - (35*\[Nu])/12) + x^(3/2)*(4*Pi - 4*s - (5*\[Delta]*\[Sigma])/4) + 
   x^(5/2)*((-8191*Pi)/672 - (9*s)/2 - (13*\[Delta]*\[Sigma])/16 + \[Nu]*((-583*Pi)/24 + (272*s)/9 + (43*\[Delta]*\[Sigma])/4)) + 
   x^2*(-44711/9072 + 8*s^2 + (65*\[Nu]^2)/18 + 8*s*\[Delta]*\[Sigma] + (33*\[Sigma]^2)/16 + \[Nu]*(9271/504 - 8*\[Sigma]^2)) + 
   x^(7/2)*((-16285*Pi)/504 + (476645*s)/6804 + 32*Pi*s^2 - (16*s^3)/3 + (9535*\[Delta]*\[Sigma])/336 + 32*Pi*s*\[Delta]*\[Sigma] + (2*s^2*\[Delta]*\[Sigma])/3 + (65*Pi*\[Sigma]^2)/8 + (9*s*\[Sigma]^2)/2 + 
     (35*\[Delta]*\[Sigma]^3)/24 + \[Nu]^2*((193385*Pi)/3024 - (2810*s)/27 - (1501*\[Delta]*\[Sigma])/36) + \[Nu]*((214745*Pi)/1728 + (6172*s)/189 + (1849*\[Delta]*\[Sigma])/126 - 32*Pi*\[Sigma]^2 - 
       (56*s*\[Sigma]^2)/3 - 6*\[Delta]*\[Sigma]^3)) + x^3*(6643739519/69854400 - (1712*EulerGamma)/105 + (16*Pi^2)/3 - 16*Pi*s - (3839*s^2)/252 - (775*\[Nu]^3)/324 - (31*Pi*\[Delta]*\[Sigma])/6 - 
     (1375*s*\[Delta]*\[Sigma])/56 - (227*\[Sigma]^2)/28 + \[Nu]*(-134543/7776 + (41*Pi^2)/48 - 43*s^2 - 43*s*\[Delta]*\[Sigma] + (3481*\[Sigma]^2)/168) + \[Nu]^2*(-94403/3024 + 43*\[Sigma]^2) - (856*Log[16*x])/105)))/(5*G);


(* ::Text:: *)
(*The following expression corresponds to Eq. (44) of the paper*)


\[Delta]F$3p5PN = (32*c^5*x^(15/2)*\[Nu]^2*(-1/4*s - (3*s^3)/2 - (9*s^2*\[Delta]*\[Sigma])/4 - (9*s*\[Sigma]^2)/4 - (3*\[Delta]*\[Sigma]^3)/4 + \[Nu]*(s/2 + (\[Delta]*\[Sigma])/4 + (9*s*\[Sigma]^2)/2 + (3*\[Delta]*\[Sigma]^3)/4) + 
   x*(-s - (9*s^3)/4 - (9*s^2*\[Delta]*\[Sigma])/16 - (9*s*\[Sigma]^2)/16 - (3*\[Delta]*\[Sigma]^3)/16 + \[Nu]^2*((-5*s)/4 - (5*\[Delta]*\[Sigma])/8 - (45*s*\[Sigma]^2)/4 - (15*\[Delta]*\[Sigma]^3)/8) + 
     \[Nu]*((13*s)/4 + (15*s^3)/4 + \[Delta]*\[Sigma] + (45*s^2*\[Delta]*\[Sigma])/8 + (9*s*\[Sigma]^2)/8 + (3*\[Delta]*\[Sigma]^3)/16))))/(5*G);


(* ::Text:: *)
(*The following expression corresponds to Eq. (47) of the paper*)


x$inTermsOf$\[Tau]$3p5PN = (1 + ((-113868647*Pi)/433520640 + (24634336547*s)/2601123840 + (21*Pi*s^2)/16 - (969085*s^3)/258048 + (281190779*\[Delta]*\[Sigma])/99090432 + (21*Pi*s*\[Delta]*\[Sigma])/16 - (969701*s^2*\[Delta]*\[Sigma])/172032 + 
    (1711*Pi*\[Sigma]^2)/5120 - (2326643*s*\[Sigma]^2)/860160 - (427997*\[Delta]*\[Sigma]^3)/1032192 + \[Nu]^2*((294941*Pi)/3870720 + (1363*s)/368640 - (3331*\[Delta]*\[Sigma])/98304 - (239*s*\[Sigma]^2)/1024 - (239*\[Delta]*\[Sigma]^3)/6144) + 
    \[Nu]*((-31821*Pi)/143360 - (102279787*s)/15482880 + (239*s^3)/3072 - (13594213*\[Delta]*\[Sigma])/4128768 + (239*s^2*\[Delta]*\[Sigma])/2048 - (21*Pi*\[Sigma]^2)/16 + (326785*s*\[Sigma]^2)/28672 + (991009*\[Delta]*\[Sigma]^3)/516096))/
   \[Tau]^(7/8) + ((-11891*Pi)/53760 + (358763*s)/161280 + s^3/32 + (96473*\[Delta]*\[Sigma])/129024 + (3*s^2*\[Delta]*\[Sigma])/64 + (3*s*\[Sigma]^2)/64 + (\[Delta]*\[Sigma]^3)/64 + 
    \[Nu]*((109*Pi)/1920 - (247*s)/5760 - (29*\[Delta]*\[Sigma])/512 - (3*s*\[Sigma]^2)/32 - (\[Delta]*\[Sigma]^3)/64))/\[Tau]^(5/8) + 
  (19583/254016 - (5*s^2)/8 + (31*\[Nu]^2)/288 - (5*s*\[Delta]*\[Sigma])/8 - (81*\[Sigma]^2)/512 + \[Nu]*(24401/193536 + (5*\[Sigma]^2)/8))/Sqrt[\[Tau]] + (-1/5*Pi + (47*s)/60 + (5*\[Delta]*\[Sigma])/16)/\[Tau]^(3/8) + 
  (743/4032 + (11*\[Nu])/48)/\[Tau]^(1/4) + (-10052469856691/6008596070400 + (107*EulerGamma)/420 + Pi^2/6 - (47*Pi*s)/48 - (1583*s^2)/4032 + (25565*\[Nu]^3)/331776 - (149*Pi*\[Delta]*\[Sigma])/384 - (529*s*\[Delta]*\[Sigma])/3584 + 
    (329*\[Sigma]^2)/8192 + \[Nu]*(3147553127/780337152 - (451*Pi^2)/3072 - (3*s^2)/8 - (3*s*\[Delta]*\[Sigma])/8 - (1175*\[Sigma]^2)/7168) + \[Nu]^2*(-15211/442368 + (3*\[Sigma]^2)/8) - (107*Log[\[Tau]/256])/3360)/\[Tau]^(3/4))/(4*\[Tau]^(1/4));


(* ::Text:: *)
(*The following expression corresponds to Eq. (49) of the paper*)


\[Psi]$3p5PN = \[Psi]0 - (1 + x*(3715/1008 + (55*\[Nu])/12) + x^(3/2)*(-10*Pi + (235*s)/6 + (125*\[Delta]*\[Sigma])/8) + x^2*(15293365/1016064 - 100*s^2 + (3085*\[Nu]^2)/144 - 100*s*\[Delta]*\[Sigma] - (405*\[Sigma]^2)/16 + \[Nu]*(27145/1008 + 100*\[Sigma]^2)) + 
   x^(7/2)*((77096675*Pi)/2032128 - (9018232555*s)/6096384 - 200*Pi*s^2 + (125925*s^3)/224 - (170978035*\[Delta]*\[Sigma])/387072 - 200*Pi*s*\[Delta]*\[Sigma] + (379805*s^2*\[Delta]*\[Sigma])/448 - (815*Pi*\[Sigma]^2)/16 + 
     (182755*s*\[Sigma]^2)/448 + (1315*\[Delta]*\[Sigma]^3)/21 + \[Nu]*((378515*Pi)/12096 + (3329545*s)/3024 - (95*s^3)/8 + (2909765*\[Delta]*\[Sigma])/5376 - (285*s^2*\[Delta]*\[Sigma])/16 + 200*Pi*\[Sigma]^2 - (385825*s*\[Sigma]^2)/224 - 
       (130615*\[Delta]*\[Sigma]^3)/448) + \[Nu]^2*((-74045*Pi)/6048 + (835*s)/288 + (7015*\[Delta]*\[Sigma])/1152 + (285*s*\[Sigma]^2)/8 + (95*\[Delta]*\[Sigma]^3)/16)) + 
   x^(5/2)*((38645*Pi)/1344 - (555605*s)/2016 - (15*s^3)/4 - (41745*\[Delta]*\[Sigma])/448 - (45*s^2*\[Delta]*\[Sigma])/8 - (45*s*\[Sigma]^2)/8 - (15*\[Delta]*\[Sigma]^3)/8 + 
     \[Nu]*((-65*Pi)/16 - (45*s)/8 + (5*\[Delta]*\[Sigma])/2 + (45*s*\[Sigma]^2)/4 + (15*\[Delta]*\[Sigma]^3)/8))*Log[x] + x^3*(12348611926451/18776862720 - (1712*EulerGamma)/21 - (160*Pi^2)/3 + (940*Pi*s)/3 + (7915*s^2)/63 - 
     (127825*\[Nu]^3)/5184 + (745*Pi*\[Delta]*\[Sigma])/6 + (2645*s*\[Delta]*\[Sigma])/56 - (1645*\[Sigma]^2)/128 + \[Nu]^2*(76055/6912 - 120*\[Sigma]^2) + 
     \[Nu]*(-15737765635/12192768 + (2255*Pi^2)/48 + 120*s^2 + 120*s*\[Delta]*\[Sigma] + (5875*\[Sigma]^2)/112) - (856*Log[16*x])/21))/(32*x^(5/2)*\[Nu]);


(* ::Text:: *)
(*The following expression corresponds to Eq. (45) of the paper [and Eq. (36) in the non-spinning case s = \[Sigma] = 0]*)


xdot$3p5PN = (64*c^3*x^5*\[Nu]*(1 + x*(-743/336 - (11*\[Nu])/4) + x^(3/2)*(4*Pi - (47*s)/3 - (25*\[Delta]*\[Sigma])/4) + x^2*(34103/18144 + 20*s^2 + (59*\[Nu]^2)/18 + 20*s*\[Delta]*\[Sigma] + (81*\[Sigma]^2)/16 + \[Nu]*(13661/2016 - 20*\[Sigma]^2)) + 
   x^(5/2)*((-4159*Pi)/672 - (5897*s)/144 - (3*s^3)/2 - (809*\[Delta]*\[Sigma])/84 - (9*s^2*\[Delta]*\[Sigma])/4 - (9*s*\[Sigma]^2)/4 - (3*\[Delta]*\[Sigma]^3)/4 + 
     \[Nu]*((-189*Pi)/8 + (1007*s)/12 + (283*\[Delta]*\[Sigma])/8 + (9*s*\[Sigma]^2)/2 + (3*\[Delta]*\[Sigma]^3)/4)) + x^(7/2)*((-4415*Pi)/4032 - (4348507*s)/18144 + 80*Pi*s^2 - (2371*s^3)/6 - (1195759*\[Delta]*\[Sigma])/18144 + 
     80*Pi*s*\[Delta]*\[Sigma] - (25325*s^2*\[Delta]*\[Sigma])/48 + (161*Pi*\[Sigma]^2)/8 - (471*s*\[Sigma]^2)/2 - (419*\[Delta]*\[Sigma]^3)/12 + \[Nu]^2*((91495*Pi)/1512 - (11213*s)/54 - (8765*\[Delta]*\[Sigma])/96 - (21*s*\[Sigma]^2)/2 - (7*\[Delta]*\[Sigma]^3)/4) + 
     \[Nu]*((358675*Pi)/6048 + (146455*s)/224 + (7*s^3)/2 + (258409*\[Delta]*\[Sigma])/1008 + (21*s^2*\[Delta]*\[Sigma])/4 - 80*Pi*\[Sigma]^2 + (5581*s*\[Sigma]^2)/6 + (2147*\[Delta]*\[Sigma]^3)/16)) + 
   x^3*(16447322263/139708800 - (1712*EulerGamma)/105 + (16*Pi^2)/3 - (188*Pi*s)/3 + (7649*s^2)/42 - (5605*\[Nu]^3)/2592 - (151*Pi*\[Delta]*\[Sigma])/6 + (19627*s*\[Delta]*\[Sigma])/168 + (3159*\[Sigma]^2)/224 + 
     \[Nu]*(-56198689/217728 + (451*Pi^2)/48 - 86*s^2 - 86*s*\[Delta]*\[Sigma] - (57221*\[Sigma]^2)/672) + \[Nu]^2*(541/896 + 86*\[Sigma]^2) - (856*Log[16*x])/105)))/(5*G*M);


(* ::Section:: *)
(*d(Ul0)/dt *)


(* ::Text:: *)
(*The following expression corresponds to Eq. (39) of the paper [and Eq. (35a) in the non-spinning case s = \[Sigma] = 0]*)


Ulm$dot$3p5PN[2,0] = (256*c^6*Sqrt[Pi/15]*x^5*\[Nu]^2*(1 + x*(-1219/288 + \[Nu]/24) + x^(3/2)*(4*Pi - (7*s)/3 + (19*\[Delta]*\[Sigma])/64) + 
   x^(5/2)*((-2435*Pi)/144 - (79*s)/9 - (1007*\[Delta]*\[Sigma])/144 + \[Nu]*((-23*Pi)/12 + (67*s)/9 + (127*\[Delta]*\[Sigma])/64)) + 
   x^2*(-793/1782 + 8*s^2 - (4201*\[Nu]^2)/1584 + 8*s*\[Delta]*\[Sigma] + (63*\[Sigma]^2)/32 + \[Nu]*(-14023/6336 - 8*\[Sigma]^2)) + 
   x^(7/2)*((-33199*Pi)/8448 + (18728305*s)/342144 + 32*Pi*s^2 + 8*s^3 + (361003*\[Delta]*\[Sigma])/19008 + 32*Pi*s*\[Delta]*\[Sigma] + (211*s^2*\[Delta]*\[Sigma])/8 + (127*Pi*\[Sigma]^2)/16 + (41*s*\[Sigma]^2)/2 + (445*\[Delta]*\[Sigma]^3)/96 + 
     \[Nu]^2*((-27949*Pi)/864 + (5167*s)/264 + (35653*\[Delta]*\[Sigma])/6336) + \[Nu]*((532909*Pi)/38016 + (29281*s)/297 + (70819*\[Delta]*\[Sigma])/1408 - 32*Pi*\[Sigma]^2 - (163*s*\[Sigma]^2)/2 - (147*\[Delta]*\[Sigma]^3)/8)) + 
   x^3*(174213949439/1816214400 - (1712*EulerGamma)/105 + (16*Pi^2)/3 - (28*Pi*s)/3 - (691*s^2)/24 + (142471*\[Nu]^3)/46332 + (121*Pi*\[Delta]*\[Sigma])/96 - (3841*s*\[Delta]*\[Sigma])/96 - (2257*\[Sigma]^2)/192 + 
     \[Nu]^2*(4168379/123552 + (15*\[Sigma]^2)/2) + \[Nu]*(-126714689/4447872 + (41*Pi^2)/48 - (15*s^2)/2 - (15*s*\[Delta]*\[Sigma])/2 + (2129*\[Sigma]^2)/48) - (856*Log[16*x])/105)))/(7*G^2);


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (35b) in the non-spinning case s = \[Sigma] = 0*)


Ulm$dot$3p5PN[4,0] = (64*c^6*Sqrt[Pi/5]*x^5*\[Nu]^2*(1 + x*(-10133/704 + (25775*\[Nu])/528) + x^(3/2)*(4*Pi + (28*s)/3 + (185*\[Delta]*\[Sigma])/16) + 
   x^(5/2)*((-1028*Pi)/11 - (33977*s)/1056 - (148201*\[Delta]*\[Sigma])/2112 + \[Nu]*((11114*Pi)/33 - (44503*s)/264 + (3041*\[Delta]*\[Sigma])/528)) + 
   x^2*(322533/4576 + 8*s^2 - (237865*\[Nu]^2)/5148 + 8*s*\[Delta]*\[Sigma] + (7*\[Sigma]^2)/4 + \[Nu]*(-721593/2288 - 8*\[Sigma]^2)) + 
   x^(7/2)*((37621537*Pi)/82368 + (113741*s)/858 + 32*Pi*s^2 + (304*s^3)/3 + (2230909*\[Delta]*\[Sigma])/13728 + 32*Pi*s*\[Delta]*\[Sigma] + (1259*s^2*\[Delta]*\[Sigma])/6 + (15*Pi*\[Sigma]^2)/2 + (401*s*\[Sigma]^2)/3 + (215*\[Delta]*\[Sigma]^3)/8 + 
     \[Nu]^2*((-8011895*Pi)/10296 + (36653195*s)/30888 + (2752261*\[Delta]*\[Sigma])/6864) + \[Nu]*((-8366815*Pi)/4576 - (5028611*s)/13728 - (12792451*\[Delta]*\[Sigma])/27456 - 32*Pi*\[Sigma]^2 - (1606*s*\[Sigma]^2)/3 - (217*\[Delta]*\[Sigma]^3)/2)) + 
   x^3*(32585924257/403603200 - (1712*EulerGamma)/105 + (16*Pi^2)/3 + (112*Pi*s)/3 - (25573*s^2)/144 - (1145725*\[Nu]^3)/92664 + (377*Pi*\[Delta]*\[Sigma])/8 - (96575*s*\[Delta]*\[Sigma])/528 - (25911*\[Sigma]^2)/704 + 
     \[Nu]^2*(16531/52 - (25423*\[Sigma]^2)/44) + \[Nu]*(4669843/164736 + (41*Pi^2)/48 + (25423*s^2)/44 + (25423*s*\[Delta]*\[Sigma])/44 + (9781*\[Sigma]^2)/33) - (856*Log[16*x])/105)))/(315*G^2);


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (35c) in the non-spinning case s = \[Sigma] = 0*)


Ulm$dot$3p5PN[6,0]= (-839*c^6*Sqrt[Pi/2730]*x^6*\[Nu]^2*(1 - (3612*\[Nu])/839 + x*(-982361/75510 + (56387*\[Nu])/839 - (62244*\[Nu]^2)/839) + 
   x^(3/2)*((5540*Pi)/839 + 14*s + (15113*\[Delta]*\[Sigma])/839 + \[Nu]*((-23184*Pi)/839 - (50568*s)/839 - (47376*\[Delta]*\[Sigma])/839)) + 
   x^(5/2)*((-488407*Pi)/4195 - (137924378*s)/1472445 - (44127983*\[Delta]*\[Sigma])/327210 + \[Nu]^2*((-9431984*Pi)/12585 + (3789480*s)/10907 + (292284*\[Delta]*\[Sigma])/54535) + 
     \[Nu]*((7810432*Pi)/12585 + (11739658*s)/32721 + (24228843*\[Delta]*\[Sigma])/54535)) + x^2*(302491414/4492845 + (6996*s^2)/839 + (1106868*\[Nu]^3)/14263 + (3972*s*\[Delta]*\[Sigma])/839 - (519*\[Sigma]^2)/839 + 
     \[Nu]*(-1516457957/3851010 - (43344*s^2)/839 - (43344*s*\[Delta]*\[Sigma])/839 - (10272*\[Sigma]^2)/839) + \[Nu]^2*(27377867/42789 + (43344*\[Sigma]^2)/839))))/(693*G^2);


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (35d) in the non-spinning case s = \[Sigma] = 0*)


Ulm$dot$3p5PN[8,0] = (75601*c^6*Sqrt[Pi/1190]*x^7*\[Nu]^2*(1 - (452070*\[Nu])/75601 + (733320*\[Nu]^2)/75601 + x*(-7655551/604808 + (369735869*\[Nu])/4309257 - (248030070*\[Nu]^2)/1436419 + (135873360*\[Nu]^3)/1436419) + 
   x^(3/2)*((708606*Pi)/75601 + (29469704*s)/1587621 + (12645567*\[Delta]*\[Sigma])/529207 + \[Nu]*((-4245492*Pi)/75601 - (58794000*s)/529207 - (63175716*\[Delta]*\[Sigma])/529207) + 
     \[Nu]^2*((6707184*Pi)/75601 + (95544000*s)/529207 + (80113752*\[Delta]*\[Sigma])/529207))))/(347490*G^2);


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (35e) in the non-spinning case s = \[Sigma] = 0*)


Ulm$dot$3p5PN[10,0]=(-525221*c^6*Sqrt[Pi/385]*x^8*\[Nu]^2*(1 - (79841784*\[Nu])/9979199 + (198570240*\[Nu]^2)/9979199 - (172307520*\[Nu]^3)/9979199))/(15752880*G^2);


(* ::Section:: *)
(*Hl0 *)


(* ::Text:: *)
(*This normalization corresponds to Eq. (26) of the paper, in the m=0 case*)


normalization$Hlm = 2*M*\[Nu]*x*Sqrt[16*Pi/5];


(* ::Text:: *)
(*The following expression corresponds to Eq. (50) of the paper [and Eq. (38a) in the non-spinning case s = \[Sigma] = 0]*)


Hlm$3p5PN[2,0] = (-5*(1 + x*(-4075/4032 + (67*\[Nu])/48) + x^(3/2)*((16*s)/3 + (419*\[Delta]*\[Sigma])/160) + x^3*(-4397711103307/532580106240 + (997*s^2)/336 + (1321981*\[Nu]^3)/5930496 + (23*Pi*\[Delta]*\[Sigma])/384 + (173191*s*\[Delta]*\[Sigma])/16128 + 
     (14171*\[Sigma]^2)/3072 + \[Nu]*(700464542023/13948526592 - (205*Pi^2)/96 - (31*s^2)/12 - (31*s*\[Delta]*\[Sigma])/12 - (142529*\[Sigma]^2)/8064) + \[Nu]^2*(69527951/166053888 + (31*\[Sigma]^2)/12)) + 
   x^2*(-151877213/67060224 - 4*s^2 + (205*\[Nu]^2)/352 - 4*s*\[Delta]*\[Sigma] - (33*\[Sigma]^2)/32 + \[Nu]*(-123815/44352 + 4*\[Sigma]^2)) + 
   x^(5/2)*((-253*Pi)/336 + (181381*s)/21168 + (3*s^3)/7 + (289127*\[Delta]*\[Sigma])/225792 + (9*s^2*\[Delta]*\[Sigma])/14 + (9*s*\[Sigma]^2)/14 + (3*\[Delta]*\[Sigma]^3)/14 + 
     \[Nu]*((253*Pi)/84 + (283*s)/252 + (1583*\[Delta]*\[Sigma])/2688 - (9*s*\[Sigma]^2)/7 - (3*\[Delta]*\[Sigma]^3)/14)) + x^(7/2)*((38351671*Pi)/28740096 + (9820292015*s)/301771008 - (68833*s^3)/6048 + 
     (14713254113*\[Delta]*\[Sigma])/3218890752 - (95153*s^2*\[Delta]*\[Sigma])/4032 + (Pi*\[Sigma]^2)/24 - (58669*s*\[Sigma]^2)/4032 - (274927*\[Delta]*\[Sigma]^3)/96768 + 
     \[Nu]^2*((-652889*Pi)/598752 - (39821*s)/14256 - (226313*\[Delta]*\[Sigma])/152064 - (77*s*\[Sigma]^2)/24 - (77*\[Delta]*\[Sigma]^3)/144) + 
     \[Nu]*((-3486041*Pi)/598752 - (1670164*s)/18711 + (77*s^3)/72 - (66525761*\[Delta]*\[Sigma])/1596672 + (77*s^2*\[Delta]*\[Sigma])/48 + (41569*s*\[Sigma]^2)/672 + (154261*\[Delta]*\[Sigma]^3)/12096))))/(14*Sqrt[6]);


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (38b) in the non-spinning case s = \[Sigma] = 0*)


Hlm$3p5PN[4,0] = -1/504*(1 + x*(-180101/29568 + (27227*\[Nu])/1056) + x^(3/2)*(10*s + (57*\[Delta]*\[Sigma])/8) + x^2*(2201411267/158505984 - 4*s^2 + (844951*\[Nu]^2)/27456 - 4*s*\[Delta]*\[Sigma] - (53*\[Sigma]^2)/48 + 
     \[Nu]*(-34829479/432432 + 4*\[Sigma]^2)) + x^3*(15240463356751/781117489152 + (1380815*s^2)/22176 + (221405645*\[Nu]^3)/11860992 + (25*Pi*\[Delta]*\[Sigma])/96 + (1303525*s*\[Delta]*\[Sigma])/14784 + (352565*\[Sigma]^2)/12288 + 
     \[Nu]*(-1029744557245/27897053184 - (205*Pi^2)/96 - (26435*s^2)/264 - (26435*s*\[Delta]*\[Sigma])/264 - (32586265*\[Sigma]^2)/236544) + \[Nu]^2*(-4174614175/36900864 + (26435*\[Sigma]^2)/264)) + 
   x^(5/2)*((-13565*Pi)/1232 - (624845*s)/17248 + (3*s^3)/7 - (179791*\[Delta]*\[Sigma])/6468 + (9*s^2*\[Delta]*\[Sigma])/14 + (9*s*\[Sigma]^2)/14 + (3*\[Delta]*\[Sigma]^3)/14 + 
     \[Nu]*((13565*Pi)/308 + (988627*s)/5544 + (360791*\[Delta]*\[Sigma])/3696 - (9*s*\[Sigma]^2)/7 - (3*\[Delta]*\[Sigma]^3)/14)) + 
   x^(7/2)*((21681663715*Pi)/747242496 + (346521837161*s)/7846046208 - (2034833*s^3)/44352 + (25969272883*\[Delta]*\[Sigma])/951035904 - (7968515*s^2*\[Delta]*\[Sigma])/88704 + (5*Pi*\[Sigma]^2)/36 - (15551353*s*\[Sigma]^2)/266112 - 
     (1672525*\[Delta]*\[Sigma]^3)/133056 + \[Nu]^2*((1502076385*Pi)/15567552 + (4059637*s)/123552 + (1541389*\[Delta]*\[Sigma])/54912 - (9149*s*\[Sigma]^2)/176 - (9149*\[Delta]*\[Sigma]^3)/1056) + 
     \[Nu]*((-4531656385*Pi)/31135104 - (254615111*s)/1415232 + (9149*s^3)/528 - (1441640251*\[Delta]*\[Sigma])/6918912 + (9149*s^2*\[Delta]*\[Sigma])/352 + (10985305*s*\[Sigma]^2)/44352 + (4667365*\[Delta]*\[Sigma]^3)/88704)))/Sqrt[2];


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (38c) in the non-spinning case s = \[Sigma] = 0*)


Hlm$3p5PN[6,0] = (4195*x*(1 - (3612*\[Nu])/839 + x*(-45661561/6342840 + (101414*\[Nu])/2517 - (48118*\[Nu]^2)/839) + 
   x^(3/2)*((1248*Pi)/839 + (356*s)/21 + (81427*\[Delta]*\[Sigma])/5873 + \[Nu]*((-4992*Pi)/839 - (61232*s)/839 - (39972*\[Delta]*\[Sigma])/839)) + 
   x^2*(3012132889099/144921208320 - (4892*s^2)/839 - (24793657*\[Nu]^3)/342312 - (6404*s*\[Delta]*\[Sigma])/839 - (76263*\[Sigma]^2)/26848 + \[Nu]^2*(1317967427/4107744 - (14448*\[Sigma]^2)/839) + 
     \[Nu]*(-27653500031/191694720 + (14448*s^2)/839 + (14448*s*\[Delta]*\[Sigma])/839 + (99175*\[Sigma]^2)/6712)) + 
   x^(5/2)*((-74044807*Pi)/2718360 - (25774585477*s)/371056140 + (2*s^3)/3 - (15289378943*\[Delta]*\[Sigma])/247370760 + s^2*\[Delta]*\[Sigma] + s*\[Sigma]^2 + (\[Delta]*\[Sigma]^3)/3 + 
     \[Nu]*((18121333*Pi)/113265 + (110541190*s)/294489 - (2408*s^3)/839 + (273780679*\[Delta]*\[Sigma])/981630 - (3612*s^2*\[Delta]*\[Sigma])/839 - (5290*s*\[Sigma]^2)/839 - (4451*\[Delta]*\[Sigma]^3)/2517) + 
     \[Nu]^2*((-26966906*Pi)/113265 - (14401340*s)/32721 - (44304028*\[Delta]*\[Sigma])/163605 + (7224*s*\[Sigma]^2)/839 + (1204*\[Delta]*\[Sigma]^3)/839))))/(1419264*Sqrt[273]);


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (38d) in the non-spinning case s = \[Sigma] = 0*)


Hlm$3p5PN[8,0] = (-75601*x^2*(1 - (452070*\[Nu])/75601 + (733320*\[Nu]^2)/75601 + x*(-265361599/33869248 + (18177898147*\[Nu])/321757856 - (722521125*\[Nu]^2)/5745676 + (261283995*\[Nu]^3)/2872838) + 
   x^(3/2)*((812404*Pi)/226803 + (108684866*s)/4762863 + (63812443*\[Delta]*\[Sigma])/3175242 + \[Nu]*((-1624808*Pi)/75601 - (72247340*s)/529207 - (55302519*\[Delta]*\[Sigma])/529207) + 
     \[Nu]^2*((2515936*Pi)/75601 + (117309840*s)/529207 + (74797668*\[Delta]*\[Sigma])/529207))))/(213497856*Sqrt[119]);


(* ::Text:: *)
(*The following expression is not given in the paper, but corresponds to Eq. (38e) in the non-spinning case s = \[Sigma] = 0*)


Hlm$3p5PN[10,0] = (525221*x^3*(1 - (79841784*\[Nu])/9979199 + (198570240*\[Nu]^2)/9979199 - (172307520*\[Nu]^3)/9979199))/(6452379648*Sqrt[154]);


(* ::Chapter:: *)
(*Self-Force PN expressions:*)


(* ::Section:: *)
(*Installing the SFPN package:*)


(* ::Text:: *)
(*See https://bhptoolkit.org/mathematica-install.html for more details and older verions of Mathematica.*)


(* ::Text:: *)
(*For Mathematica 12.1 or newer*)


(*Add the Black Hole Perturbation Toolkit paclet server to Mathematica\[CloseCurlyQuote]s list of paclet servers.*)
PacletSiteRegister["https://pacletserver.bhptoolkit.org", "Black Hole Perturbation Toolkit Paclet Server"];
(*Get an updated list of packages available on the server.*)
PacletSiteUpdate["https://pacletserver.bhptoolkit.org"];
(*To see which paclets are available:*)
PacletFindRemote["*", <|"Location" -> "https://pacletserver.bhptoolkit.org"|>]
(*Install the latest version of the PNSF package*)
PacletInstall["PostNewtonianSelfForce"];


(* ::Section:: *)
(*Extracting the memory expressions (version 0.5.0 of the package or newer)*)


<<PostNewtonianSelfForce`


(*List all available PN series*)
PostNewtonianExpansion[]

(*Save the l=2, m=0 memory to variables*)
PNMemh = PostNewtonianExpansion["Kerr/Circular/Memory/h-l2m0"];
PNMemhdot = PostNewtonianExpansion["Kerr/Circular/Memory/hdot-l2m0"];

(*Extract the memory expressions as in the paper*)
PNMemh["Series"]
PNMemhdot["Series"]


(* ::Text:: *)
(*For more examples of how to use this package, see https://bhptoolkit.org/PostNewtonianSelfForce/*)
